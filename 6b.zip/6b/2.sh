media=`awk {print $2}`

contador=0
for (( i = 0; i < $media; i++ )); do
	contador=$((contador + media[i]))
done
contador= `echo $contador/10`