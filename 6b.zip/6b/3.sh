llovido=`awk {print precipitaciones.txt $2}`
nollueve

for (( i = 0; i < $llovido; i++ )); do
	if [[ llovido[i] == 0 ]]; then
		nollueve = ((nollueve+1))
	fi
	contador=$((contador + media[i]))
done
contador= `echo $contador/10`