x=$1
nombres=`cat nombres.txt | wc -l`
for (( i = 0; i < $nombres; i++ )); do
	nombre=`cat nombres.txt | head -$i | tail -1`
	`mkdir "$nombre"`
	for (( i = 0; i < $x; i++ )); do
		`mkdir -p /home/alvaro/6b/$
	done
done