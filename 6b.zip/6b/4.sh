
for (( i = 0; i < 12; i++ )); do

	numeros=`cat nombres.txt | head -$i | tail -1`

	if [[ numeros%2==0 ]]; then
		echo es par
	else
		echo no es par
	fi
done




